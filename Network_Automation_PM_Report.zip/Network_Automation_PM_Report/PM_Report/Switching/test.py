from File_to_call import run_on_path

summary = run_on_path(r"C:\Users\girish.n\OneDrive - NTT\Desktop\Desktop\Live Updates\Uptime\Tickets-Mostly PM\R&S\SVR137436091\9200", ticket="SVR1234567")
print(summary)