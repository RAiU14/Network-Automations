# Cisco_IOS.py
# Phase 3a — IOS Classic parser (Catalyst 2960/3560/3750 families, 12.x/15.x)
# Goal: Keep IOS-XE logic untouched; provide a parallel module with the SAME output schema.

import os
import re
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

# ---------------------------
# Logging guard (avoid dupes)
# ---------------------------
if not logging.getLogger().handlers:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

# ---------------------------
# IPv4 helpers (strict)
# ---------------------------
_IP_RE = re.compile(r'^\s*(\d+)\.(\d+)\.(\d+)\.(\d+)\s*$')

def _is_valid_ipv4(ip: str) -> bool:
    m = _IP_RE.match(str(ip).strip())
    if not m:
        return False
    octs = [int(x) for x in m.groups()]
    return all(0 <= o <= 255 for o in octs)

def sanitize_ipv4(value: str) -> str:
    """
    Return normalized IPv4 (no leading zeros) or a status string.
    """
    if value is None:
        return "Not available"
    s = str(value).strip()
    if s == "" or s.lower() in {"n/a","na","not available","unavailable"}:
        return "Not available"

    # Handle "10.1.2.3/24" or "10.1.2.3 255.255.255.0"
    if "/" in s:
        s = s.split("/", 1)[0].strip()
    elif " " in s and _IP_RE.search(s.split(" ")[0] or ""):
        s = s.split(" ", 1)[0].strip()

    m = _IP_RE.match(s)
    if not m:
        return "Require Manual Check"

    octets = [int(x) for x in m.groups()]
    if any(o < 0 or o > 255 for o in octets):
        return "Require Manual Check"

    s_norm = ".".join(str(o) for o in octets)
    if s_norm in {"0.0.0.0","255.255.255.255"}:
        return "Require Manual Check"
    return s_norm

# ---------------------------------
# IP extraction tailored for IOS
# ---------------------------------
_CTX_AFTER = re.compile(r'^\s*(no ip (?:redirects|unreachables|proxy-arp|route-cache))\s*$', re.IGNORECASE | re.MULTILINE)

def get_ip_from_content(log_data: str) -> str | None:
    """
    Find management IP using IOS-style 'ip address A.B.C.D MASK' within
    an interface stanza that also carries mgmt-hardening lines.
    """
    if not log_data:
        return None

    # 1) Strong pattern: "ip address X.X.X.X Y.Y.Y.Y" followed by any mgmt hints in the same iface block.
    #    We capture IPv4 and then ensure at least one of the mgmt lines exists within the next ~12 lines.
    ip_line_re = re.compile(
        r'(?mi)^\s*ip address\s+(?P<ip>\d{1,3}(?:\.\d{1,3}){3})\s+\d{1,3}(?:\.\d{1,3}){3}\s*$'
    )
    for m in ip_line_re.finditer(log_data):
        ip = m.group("ip")
        if not _is_valid_ipv4(ip):
            continue
        # window after the ip-address line
        tail_start = m.end()
        tail = log_data[tail_start: tail_start + 1200]  # ~12 lines window
        if _CTX_AFTER.search(tail):
            return ip  # confident it's the mgmt SVI or mgmt iface

    # 2) Moderate pattern: "interface VlanXX" block containing ip address.
    block_re = re.compile(
        r'(?mis)^\s*interface\s+Vlan\d+\s*(?P<body>.*?)(?=^\S|\Z)'
    )
    for b in block_re.finditer(log_data):
        body = b.group("body") or ""
        m = re.search(r'(?mi)^\s*ip address\s+(\d{1,3}(?:\.\d{1,3}){3})\s+\d{1,3}(?:\.\d{1,3}){3}\s*$', body)
        if m and _is_valid_ipv4(m.group(1)):
            return m.group(1)

    # 3) Last-chance: any IPv4 in file
    any_ip = re.search(r'\b(\d{1,3}(?:\.\d{1,3}){3})\b', log_data)
    if any_ip and _is_valid_ipv4(any_ip.group(1)):
        return any_ip.group(1)

    return None

def get_ip_address(file_path: str) -> tuple[str, str]:
    """
    Filename-first IPv4; fallback to content with IOS heuristics.
    Returns (file_name, ip_or_status).
    """
    try:
        file_name = os.path.basename(file_path) if isinstance(file_path, str) else str(file_path)

        # 1) Filename candidates (validate strictly)
        filename_candidates = re.findall(r'(\d{1,3}(?:\.\d{1,3}){3})', file_name)
        for cand in filename_candidates:
            if _is_valid_ipv4(cand):
                return (file_name, sanitize_ipv4(cand))

        # 2) Content fallback
        try:
            with open(file_path, "r", errors="ignore", encoding="utf-8") as f:
                data = f.read()
        except Exception:
            try:
                with open(file_path, "r", errors="ignore") as f:  # encoding fallback
                    data = f.read()
            except Exception as inner:
                logging.warning(f"[IOS] Could not read file for IP: {file_name}: {inner}")
                return (file_name, "Require Manual Check")

        ip = get_ip_from_content(data)
        if ip:
            return (file_name, sanitize_ipv4(ip))

        # (Optional) hook: if you have your older helper `get_ip(data)` keep it here as a last-chance
        # _legacy = get_ip(data)
        # if _legacy and _is_valid_ipv4(_legacy):
        #     return (file_name, sanitize_ipv4(_legacy))

        return (file_name, "Require Manual Check")
    except Exception as e:
        logging.error(f"[IOS] get_ip_address error: {e}")
        safe = os.path.basename(file_path) if isinstance(file_path, str) else "Unknown"
        return (safe, "Require Manual Check")

# ---------------------------
# Core field parsers (IOS)
# ---------------------------

def _read_file_text(file_path: str) -> str:
    try:
        with open(file_path, "r", errors="ignore", encoding="utf-8") as f:
            return f.read()
    except Exception:
        with open(file_path, "r", errors="ignore") as f:
            return f.read()

def get_hostname(data: str) -> str:
    # IOS: "hostname <NAME>"
    m = re.search(r'(?mi)^\s*hostname\s+([^\s#]+)\s*$', data)
    return m.group(1).strip() if m else "Not available"

def get_model(data: str) -> str:
    # Examples seen in "show version" for IOS classic:
    # "cisco WS-C2960S-24PS-L (PowerPC405) processor ..."
    m = re.search(r'(?i)cisco\s+([A-Z0-9\-]+)\s*\(', data)
    if m:
        return m.group(1).strip()
    # Alt: "Model number                    : WS-C2960S-24PS-L"
    m = re.search(r'(?mi)^\s*Model\s+number\s*:\s*([A-Z0-9\-]+)\s*$', data)
    return m.group(1).strip() if m else "Not available"

def get_serial(data: str) -> str:
    # "System serial number            : FOC1234ABCD"
    m = re.search(r'(?mi)^\s*(?:System )?serial number\s*:\s*([A-Z0-9]+)\s*$', data)
    if m:
        return m.group(1).strip()
    # Alt common: "Processor board ID FDO2201E0SC"
    m = re.search(r'(?mi)^\s*Processor board ID\s+([A-Z0-9]+)\s*$', data)
    return m.group(1).strip() if m else "Not available"

def get_version(data: str) -> str:
    # "Cisco IOS Software, C2960S Software (C2960S-UNIVERSALK9-M), Version 15.0(2)SE10, RELEASE SOFTWARE (fc3)"
    m = re.search(r'(?mi)^\s*Cisco IOS Software.*Version\s+([^\s,]+)', data)
    return m.group(1).strip() if m else "Not available"

def get_uptime(data: str) -> str:
    # "<hostname> uptime is X weeks, Y days, Z hours"
    # try to pull hostname first to avoid mismatches
    host = get_hostname(data)
    if host and host != "Not available":
        pat = rf'(?mi)^\s*{re.escape(host)}\s+uptime is\s+(.+?)\s*$'
        m = re.search(pat, data)
        if m:
            return m.group(1).strip()
    # Generic fallback (less precise)
    m = re.search(r'(?mi)^\s*\S+\s+uptime is\s+(.+?)\s*$', data)
    return m.group(1).strip() if m else "Not available"

def get_last_reboot_reason(data: str) -> str:
    # IOS usually shows "System returned to ROM by power-on"
    m = re.search(r'(?mi)^\s*System returned to ROM by\s+(.+?)\s*$', data)
    if m:
        return m.group(1).strip()
    # Or "Last reload reason: PowerOn"
    m = re.search(r'(?mi)^\s*Last reload reason\s*:\s*(.+?)\s*$', data)
    return m.group(1).strip() if m else "Not available"

def get_debug_status(data: str) -> str:
    # If your run has a "debug" command not found we normalize; otherwise leave "NO".
    # This stub returns "Command not found" only if a typical message exists; else "NO".
    if re.search(r'(?i)invalid input detected|unknown command|unrecognized command', data):
        return "Command not found"
    return "NO"

def get_cpu_utilization(data: str) -> str:
    # Classic IOS "show processes cpu" often summarized as:
    # "CPU utilization for five seconds: 1%/0%; one minute: 2%; five minutes: 3%"
    m = re.search(r'(?mi)CPU utilization for five seconds:\s*([\d\.]+)%', data)
    return f"{m.group(1)}%" if m else "Not available"

def get_memory(data: str) -> tuple[str, str, str, str]:
    """
    Returns (total, used, free, util%)
    IOS 'show memory' can vary; we’ll use the Processor pool summary when present.
    Example:
      Processor  123456K total, 78910K used, 44546K free
    """
    m = re.search(
        r'(?mi)^\s*Processor\s+(\d+)\w*\s+total,\s+(\d+)\w*\s+used,\s+(\d+)\w*\s+free',
        data
    )
    if not m:
        return ("Not available","Not available","Not available","Not available")
    total = int(m.group(1)) * 1024
    used  = int(m.group(2)) * 1024
    free  = int(m.group(3)) * 1024
    util = (used / total * 100) if total else 0.0
    return (str(total), str(used), str(free), f"{util:.2f}%")

def get_flash(data: str) -> tuple[str, str, str, str]:
    """
    Returns (total, used, free, used%)
    IOS 'dir flash:' and 'show flash:' vary; we look for 'bytes total (bytes free)'.
    Example:
      32514048 bytes total (15929344 bytes free)
    """
    m = re.search(r'(?mi)(\d+)\s+bytes total\s*\(\s*(\d+)\s+bytes free\)', data)
    if not m:
        return ("Not available","Not available","Not available","Not available")
    total = int(m.group(1))
    free  = int(m.group(2))
    used  = total - free
    used_pct = (used / total * 100) if total else 0.0
    return (str(total), str(used), str(free), f"{used_pct:.2f}%")

def get_fan_status(_data: str) -> str:
    # Many Catalyst IOS models don’t expose fan status via same XE commands.
    return "Not available"

def get_temperature_status(_data: str) -> str:
    return "Not available"

def get_psu_status(_data: str) -> str:
    return "Not available"

def get_available_ports(data: str) -> int:
    """
    Best-effort: count 'down/down' access ports as free.
    This is intentionally conservative and safe.
    """
    # Typical line: "GigabitEthernet1/0/24  ...  down    down"
    cnt = 0
    for _ in re.finditer(r'(?mi)^\s*(?:Gi|Fa|Te|Eth|GigabitEthernet|FastEthernet)\S+\s+.*\bdown\s+down\b', data):
        cnt += 1
    return cnt

def get_half_duplex_ports(data: str) -> int:
    """
    Count half-duplex ports from 'show interfaces status' or similar.
    """
    return len(re.findall(r'(?mi)\bhalf-?duplex\b', data))

def get_interface_remark(data: str) -> str:
    """
    Put a short note when we see errdisabled, packet errors, etc.
    """
    if re.search(r'(?mi)\berr-?disable', data):
        return "Some interfaces err-disabled"
    if re.search(r'(?mi)input errors|CRC|late collisions', data):
        return "Interfaces show errors"
    return "Not available"

# ---------------------------
# Output shaping
# ---------------------------

COLUMNS = [
    'File name', 'Host name', 'Model number', 'Serial number', 'Interface ip address',
    'Uptime', 'Current s/w version', 'Current SW EOS', 'Suggested s/w ver', 's/w release date',
    'Latest S/W version', 'Production s/w is deffered or not?', 'Last Reboot Reason', 'Any Debug?',
    'CPU Utilization', 'Total memory', 'Used memory', 'Free memory', 'Memory Utilization (%)',
    'Total flash memory', 'Used flash memory', 'Free flash memory', 'Used Flash (%)',
    'Fan status', 'Temperature status', 'PowerSupply status', 'Available Free Ports',
    'End-of-Sale Date: HW', 'Last Date of Support: HW', 'End of Routine Failure Analysis Date:  HW',
    'End of Vulnerability/Security Support: HW', 'End of SW Maintenance Releases Date: HW',
    'Any Half Duplex', 'Interface/Module Remark', 'Config Status', 'Config Save Date',
    'Critical logs', 'Remark'
]

def _empty_row() -> dict:
    return {k: "Not available" for k in COLUMNS}

def _placeholder_entry(file_path: str, remark: str = "Parser error") -> dict:
    """
    Used when a file cannot be parsed; fills safe defaults but marks Remark.
    """
    row = _empty_row()
    row['File name'] = os.path.basename(file_path)
    row['Remark'] = remark
    # Keep "Unsupported IOS" style for attributes where you prefer to flag visually:
    for k in COLUMNS:
        if k not in ('File name', 'Remark'):
            row[k] = "Not available"
    return row

# ---------------------------
# Main per-file processor
# ---------------------------

def process_file(file_path: str) -> dict:
    """
    Parse ONE IOS Classic device log into the standard schema.
    All values are strings (or integers where obvious), never None.
    """
    try:
        file_name, ip = get_ip_address(file_path)
        data = _read_file_text(file_path)

        host = get_hostname(data)
        model = get_model(data)
        serial = get_serial(data)
        ver = get_version(data)
        uptime = get_uptime(data)
        last_reboot = get_last_reboot_reason(data)
        debug = get_debug_status(data)
        cpu = get_cpu_utilization(data)

        mem_total, mem_used, mem_free, mem_pct = get_memory(data)
        f_total, f_used, f_free, f_pct = get_flash(data)

        fan = get_fan_status(data)
        temp = get_temperature_status(data)
        psu = get_psu_status(data)

        free_ports = get_available_ports(data)
        half_duplex = get_half_duplex_ports(data)
        iface_remark = get_interface_remark(data)

        row = _empty_row()
        row.update({
            'File name': file_name,
            'Host name': host,
            'Model number': model,
            'Serial number': serial,
            'Interface ip address': ip,

            'Uptime': uptime,
            'Current s/w version': ver,
            'Current SW EOS': "Not available",
            'Suggested s/w ver': "Yet to check",
            's/w release date': "Not available",
            'Latest S/W version': "Yet to check",
            'Production s/w is deffered or not?': "Yet to check",

            'Last Reboot Reason': last_reboot,
            'Any Debug?': debug,

            'CPU Utilization': cpu,
            'Total memory': mem_total,
            'Used memory': mem_used,
            'Free memory': mem_free,
            'Memory Utilization (%)': mem_pct,

            'Total flash memory': f_total,
            'Used flash memory': f_used,
            'Free flash memory': f_free,
            'Used Flash (%)': f_pct,

            'Fan status': fan,
            'Temperature status': temp,
            'PowerSupply status': psu,

            'Available Free Ports': free_ports,
            'End-of-Sale Date: HW': "Not Announced",
            'Last Date of Support: HW': "Not Announced",
            'End of Routine Failure Analysis Date:  HW': "Not Announced",
            'End of Vulnerability/Security Support: HW': "Not Announced",
            'End of SW Maintenance Releases Date: HW': "Not Announced",

            'Any Half Duplex': half_duplex,
            'Interface/Module Remark': iface_remark,
            'Config Status': "Yes" if "write memory" in data or "copy running-config startup-config" in data else "Not available",
            'Config Save Date': "Not available",
            'Critical logs': "NO",
            'Remark': "Device operating with good parameters."
        })
        return row

    except Exception as e:
        logging.error(f"[IOS] process_file failed for {file_path}: {e}")
        return _placeholder_entry(file_path, remark="Parser error")

# ---------------------------
# Directory processor
# ---------------------------

def _eligible(fn: str) -> bool:
    name = os.path.basename(fn)
    if name.startswith(".") or name.endswith("~"):
        return False
    # Only text-like dumps
    return name.lower().endswith((".txt", ".log"))

def process_directory(directory_path: str, workers: int = 8) -> list[dict]:
    """
    Walk directory and parse all eligible IOS logs in parallel.
    """
    if not directory_path or not os.path.isdir(directory_path):
        logging.warning(f"[IOS] Invalid directory: {directory_path}")
        return []

    files = [os.path.join(directory_path, f) for f in os.listdir(directory_path) if _eligible(f)]
    results: list[dict] = []

    if not files:
        return results

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(process_file, fp): fp for fp in files}
        for fut in as_completed(futs):
            try:
                row = fut.result()
                if isinstance(row, dict):
                    results.append(row)
            except Exception as e:
                logging.error(f"[IOS] Worker crashed: {e}")
                results.append(_placeholder_entry(futs[fut], remark="Parser error"))

    return results

def print_data(data):
    try:
        logging.info("Starting data printing.")
        for key, value in data.items():
            if isinstance(value, dict):
                print(f"{key}:")
                for k, v in value.items():
                    print(f"  {k}: {v}")
            else:
                print(f"{key}: {value}")
        print("\n")
        logging.debug("Data printing completed.")
    except Exception as e:
        logging.error(f"Error in print_data: {str(e)}")
        # print(f"Error in print_data: {str(e)}")

def main():
    try:
        file_path = r"C:\Users\girish.n\OneDrive - NTT\Desktop\Desktop\Live Updates\Uptime\Tickets-Mostly PM\R&S\SVR137436091\3000\UOBM-C3650-IMB-OA-03_10.58.139.12.txt"
        # directory_path = r"C:\Users\girish.n\OneDrive - NTT\Desktop\Desktop\Live Updates\Uptime\Tickets-Mostly PM\R&S\SVR136818637\CBJ_SVR136818637\New Folder"
        data = process_file(file_path)
        print_data(data)
        # for item in data:
        #     # print(item["Interface ip address"])
        #     print_data(item)
        # pp.pprint(data["Interface ip address"])
    except Exception as e:
        print(f"Error in main: {str(e)}")

if __name__ == "__main__":
    main()