import os
import shutil
import pandas as pd
import logging
import datetime
import sys
import json
import Cisco_IOS_XE

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
database_dir = os.path.join(parent_dir, 'Database')
eox_dir = os.path.join(parent_dir, 'EOX')

sys.path.insert(0, database_dir)
sys.path.insert(0, eox_dir)

json_directory_path = r"Database\JSON_Files\eox_pid.json"

# Setup logging
log_dir = os.path.join(os.path.dirname(__file__), "Data_to_Excel")
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(filename=os.path.join(log_dir, f"{datetime.datetime.today().strftime('%Y-%m-%d')}.log"), level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

# This function is used to write/append values to excel.
def append_to_excel(ticket_number, data_list, file_path=None, column_order=None):
    logging.debug(f"Appending to Excel for ticket{ticket_number}")
    if column_order is None:
        column_order = [
            'File name', 'Host name', 'Model number', 'Serial number', 'Interface ip address',
            'Uptime', 'Current s/w version', 'Current SW EOS', 'Suggested s/w ver', 's/w release date',
            'Latest S/W version', 'Production s/w is deffered or not?', 'Last Reboot Reason', 'Any Debug?',
            'CPU Utilization', 'Total memory', 'Used memory', 'Free memory', 'Memory Utilization (%)',
            'Total flash memory', 'Used flash memory', 'Free flash memory', 'Used Flash (%)',
            'Fan status', 'Temperature status', 'PowerSupply status', 'Available Free Ports',
            'End-of-Sale Date: HW', 'Last Date of Support: HW', 'End of Routine Failure Analysis Date: HW',
            'End of Vulnerability/Security Support: HW', 'End of SW Maintenance Releases Date: HW',
            'Any Half Duplex', 'Interface/Module Remark', 'Config Status', 'Config Save Date',
            'Critical logs', 'Remark'
        ]
    if file_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = f"{ticket_number}_network_analysis_{timestamp}.xlsx"

    formatted_data = []

    if isinstance(data_list, dict):
        data_list = [data_list]  
    
    for data in data_list:
        if not isinstance(data, dict):
            logging.error(f"Skipping invalid data: {type(data)} for {ticket_number}.")
            continue
        if not data:
            continue
        data_length = 1
        for value in data.values():
            if isinstance(value, list) and len(value) > 0:
                data_length = len(value)
                break
        for i in range(data_length):
            row_data = {}
            for key in column_order:
                if key in data:
                    value = data[key]
                    if isinstance(value, list):
                        row_data[key] = value[i] if i < len(value) else 'NA'
                    else:
                        row_data[key] = value
                else:
                    row_data[key] = 'NA'
            formatted_data.append(row_data)

    if not formatted_data:
        logging.warning("No data to write to Excel.")
        return None

    df = pd.DataFrame(formatted_data)
    df = df[column_order]

    try:
        if os.path.exists(file_path):
            logging.info(f"Appending to existing Excel file: {file_path}")
            existing_df = pd.read_excel(file_path)
            combined_df = pd.concat([existing_df, df], ignore_index=True)
            combined_df.to_excel(file_path, index=False)
        else:
            logging.info(f"Creating new Excel file: {file_path}")
            df.to_excel(file_path, index=False)
        logging.debug(f"Successfully wrote {len(df)} rows to Excel file and saved in {file_path}")
        return file_path
    except Exception as e:
        logging.error(f"Error writing to Excel for case {ticket_number}: {str(e)}")
        return None

# This is to make a copy of excel. 
def process_eox_analysis(original_excel_path):
    logging.info(f"Creating copy of {original_excel_path}")
    try:
        directory = os.path.dirname(original_excel_path)
        filename = os.path.basename(original_excel_path)
        copy_filename = f"copy_{filename}"
        copy_excel_path = os.path.join(directory, copy_filename)
        shutil.copy2(original_excel_path, copy_excel_path)
        logging.debug(f"Created copy: {copy_excel_path}")
        return {
            'status': 'success',
            'copy_excel_path': copy_excel_path
        }
    except Exception as e:
        logging.error(f"Copy creation failed: {e}")
        return {
            'status': 'failed',
            'copy_excel_path': None
        }

def unique_model_numbers(data_list):
    try:
        model_numbers = set()
        
        # FIXED: Handle both single dict and list of dicts
        if isinstance(data_list, dict):
            data_list = [data_list]
        
        for data in data_list:
            if isinstance(data, dict) and "Model number" in data:
                model_value = data["Model number"]
                
                if isinstance(model_value, list):
                    # Handle list of model numbers (multiple switches)
                    model_numbers.update([model for model in model_value if model and model != 'NA'])
                elif model_value and model_value != 'NA':
                    # Handle single model number
                    model_numbers.add(model_value)
        
        return list(model_numbers)
    except Exception as e:
        print(f"Error extracting model numbers: {str(e)}")
        return []

def get_unique_serial_numbers(data_list):
    """
    Extract unique serial numbers from processed data
    """
    try:
        serial_numbers = set()
        
        if isinstance(data_list, dict):
            data_list = [data_list]
        
        for data in data_list:
            if isinstance(data, dict) and "Serial number" in data:
                serial_value = data["Serial number"]
                
                if isinstance(serial_value, list):
                    serial_numbers.update([serial for serial in serial_value if serial and serial != 'NA'])
                elif serial_value and serial_value != 'NA':
                    serial_numbers.add(serial_value)
        
        return list(serial_numbers)
    except Exception as e:
        print(f"Error extracting serial numbers: {str(e)}")
        return []

def process_and_export(ticket_number, directory_path, output_file_path=None):
    try:
        print(f"Processing directory: {directory_path}")
        
        # Process the directory
        data_list = Cisco_IOS_XE.process_directory(directory_path)
        
        if not data_list:
            return {"success": False, "error": "No data processed from directory"}
        
        print(f"Processed {len(data_list)} data sets")
        
        # Extract unique information
        model_numbers = unique_model_numbers(data_list)
        serial_numbers = get_unique_serial_numbers(data_list)
        
        # Export to Excel
        excel_file = append_to_excel(ticket_number, data_list, output_file_path)
        
        return {
            "success": True,
            "excel_file": excel_file,
            "data_count": len(data_list),
            "unique_models": model_numbers,
            "unique_serials": serial_numbers,
            "summary": f"Processed {len(data_list)} switches with {len(model_numbers)} unique models"
        }
        
    except Exception as e:
        print(f"Error in processing pipeline: {str(e)}")
        return {"success": False, "error": str(e)}
    
def request_EOX_data_from_local_db_check(pid_list, db_path):
    EOX_data = {}

    try:
        logging.info(f"Reading local DB: {db_path}")
        with open(db_path, 'r') as f:
            data = json.load(f)
        for pid in pid_list:
            logging.info(f"Checking PID={pid} in local DB")
            entry = data.get(pid)
            if entry:
                logging.debug(f"Found entry for PID={pid}: {entry}")
                EOX_data[pid] = [True, entry]
            else:
                logging.debug(f"No entry found for PID={pid}")
                EOX_data[pid] = [False, "Check EOX data online"]
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logging.error(f"Error reading local DB: {e}")
        return {pid: [False, "Failed to load data from database"] for pid in pid_list}

    logging.info("Local DB check completed.")
    return EOX_data

def update_eol_data(data, local_eol):
    try:
        data_ready_to_excel = []
        devices_without_eol = []

        for device in data:
            model_numbers = device['Model number']
            for i, model_number in enumerate(model_numbers):
                if model_number in local_eol:
                    if local_eol[model_number][0]:
                        device['End-of-Sale Date: HW'][i] = local_eol[model_number][1]['End-of-Sale Date: HW']
                        device['Last Date of Support: HW'][i] = local_eol[model_number][1]['Last Date of Support: HW']
                        device['End of Routine Failure Analysis Date: HW'][i] = local_eol[model_number][1]['End of Routine Failure Analysis Date: HW']
                        device['End of Vulnerability/Security Support: HW'][i] = local_eol[model_number][1]['End of Vulnerability/Security Support: HW']
                        device['End of SW Maintenance Releases Date: HW'][i] = local_eol[model_number][1]['End of SW Maintenance Releases Date: HW']
                    else:
                        device['End-of-Sale Date: HW'][i] = local_eol[model_number][1]
                        device['Last Date of Support: HW'][i] = 'EOL data not available'
                        device['End of Routine Failure Analysis Date: HW'][i] = 'EOL data not available'
                        device['End of Vulnerability/Security Support: HW'][i] = 'EOL data not available'
                        device['End of SW Maintenance Releases Date: HW'][i] = 'EOL data not available'
                        devices_without_eol.append(model_number)
                else:
                    device['End-of-Sale Date: HW'][i] = 'Model not found in EOL data'
                    device['Last Date of Support: HW'][i] = 'Model not found in EOL data'
                    device['End of Routine Failure Analysis Date: HW'][i] = 'Model not found in EOL data'
                    device['End of Vulnerability/Security Support: HW'][i] = 'Model not found in EOL data'
                    device['End of SW Maintenance Releases Date: HW'][i] = 'Model not found in EOL data'
                    devices_without_eol.append(model_number)
            data_ready_to_excel.append(device)
        
        return [data_ready_to_excel, devices_without_eol]
    except Exception as e:
        return f"Error in update_eol_data: {str(e)}"

def final_offline_sheet(ticket_number,directory_path):
    try:
        json_directory_path = r"Database\JSON_Files\eox_pid.json"
        
        if os.path.exists(directory_path):
            list_dict_list = Cisco_IOS_XE.process_directory(directory_path)
            unique_models = unique_model_numbers(list_dict_list)
            eox_local_pull = request_EOX_data_from_local_db_check(unique_models, json_directory_path)
            result = update_eol_data(list_dict_list, eox_local_pull)
            
            if isinstance(result, str) and result.startswith("Error"):
                return result
            
            data_ready_to_excel, devices_without_eol = result
            
            if data_ready_to_excel:
                excel_result = append_to_excel(ticket_number, data_ready_to_excel, f"{ticket}_test.xlsx")
                if excel_result:
                    return f"File created and saved in root directory", devices_without_eol 
                else:
                    return "Failed to create Excel file", devices_without_eol 
            else:
                return "No data returned from file processing", devices_without_eol 
        else:
            return f"Directory not found: {directory_path}", []
    except Exception as e:
        return f"Error in final_offline_sheet: {str(e)}", []

if __name__ == "__main__":
    final_offline_sheet()